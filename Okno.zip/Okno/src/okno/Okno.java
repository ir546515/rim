package okno;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
 
public class Okno implements ActionListener {
 
   public Okno() {
      initComponents();
   }
 
   private JFrame viewForm;
 
   private void initComponents() {
      viewForm = new JFrame("Окно");
      viewForm.setSize(320, 160);
      viewForm.setVisible(true);
      viewForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      
 
      JButton button1 = new JButton("Подробнее");
      button1.setVisible(true);
      button1.setLocation(20, 50);
      button1.setSize(120, 20);

      
      JButton button = new JButton("Начать работу");
      button.setVisible(true);
      button.setLocation(150, 50); //(влево, вниз); 
      button.setSize(150,20); //(ширь, Высота)
      button.addActionListener(new ActionListener() {
 
          public void actionPerformed(ActionEvent arg0) {
             NewJFrame NewJFrame = new NewJFrame();
             NewJFrame.setVisible(true);
             NewJFrame.pack();



         }
 
      });
      viewForm.getContentPane().add(button1);
      viewForm.getContentPane().add(button);
      viewForm.getContentPane().add(new JLabel());
   }
 
   public void actionPerformed(ActionEvent action) {
   }
 
   public static void main(String[] args) {
      SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            new Okno();
         }
      });
   }
}